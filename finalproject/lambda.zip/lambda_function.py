import boto3
import os
import json
import requests
from contextlib import closing


TELE_TOKEN=os.environ['BOT_ID']
URL = "https://api.telegram.org/bot{}/".format(TELE_TOKEN)

s3 = boto3.client('s3')

def generate_voice(text, filename):
    polly_client = boto3.client('polly')
    response = polly_client.synthesize_speech(VoiceId=os.environ['VOICE_NAME'],
                    OutputFormat='ogg_vorbis', 
                    Text = text)
    
    with closing(response["AudioStream"]) as stream:
                output = os.path.join("/tmp/", filename)
                with open(output, "wb") as file:
                    file.write(stream.read())


    s3.upload_file('/tmp/' + filename, 
      os.environ['S3_BUCKET_NAME'], 
      filename)


def send_audio(chat_id, link, filename):
    url = URL + "sendVoice?voice={}&chat_id={}".format(link, chat_id)
    requests.get(url)
    
    s3.delete_object( 
        Bucket=os.environ['S3_BUCKET_NAME'],
        Key=filename
        )
        
def send_message(chat_id):
    final_text = os.environ['START_MESSAGE']
    url = URL + "sendMessage?text={}&chat_id={}".format(final_text, chat_id)
    requests.get(url)
	
def lambda_handler(event, context):
        message = json.loads(event['body'])['message']
        chat_id = message['chat']['id']
        reply = message['text']
        command = reply.split()[0][1:]
        filename = '_'.join(reply.split()[:3]) + ".ogg"
        audio_link = "https://{}.s3.{}.amazonaws.com/{}".format(os.environ['S3_BUCKET_NAME'], os.environ['REGION'], filename)
        if command=="start": 
            send_message(chat_id)
        else:
            generate_voice(reply, filename)
            send_audio(chat_id, audio_link, filename)
        return {
            'statusCode': 200
        }